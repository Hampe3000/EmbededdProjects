/*
 * motor.h
 *
 * Created: 2022-01-05 17:45:44
 *  Author: Hampus & Robin
 */ 
#ifndef MOTOR_H_
#define MOTOR_H_

#include <inttypes.h>

void motor_init(void);
void motor_set_speed(uint8_t);
#endif