/*
 * lab6.c
 *
 * Created: 04/01/2022 9:01:51 AM
 *  Author: Hampus och Robin
 */ 

//includes necessary files for the project
#include <xc.h>
#include <stdio.h>
#include "delay/delay.h"
#include "lcd/lcd.h"
#include "hmi/hmi.h"
#include "regulator/regulator.h"
#include "numkey/numkey.h"
#include "motor/motor.h"

//main part of program
int main(void)
{
	hmi_init(); // initierar HMI(LCD och numkey)
	regulator_init(); // initierar regulator
	motor_init();//initierar motor
	//declares instans variables
	char key; 
	uint8_t pwr;
	state_t current_state = MOTOR_OFF; //initial state
	state_t next_state = MOTOR_OFF;
	
	//declares some strings used by the state machine
	char motor_str[9]; 
	char motor_off[] = "Motor is off";
	char motor_on[] = "Motor is on";
	char motor_running[] = "Motor power at:";
	
    while(1)//infinite loop and state machine
    {
		key = numkey_read(); //reads the numpad
		pwr = regulator_read_power(); //read the value from the potentiometer
		switch(current_state)
		{
			case MOTOR_OFF: 
				lcd_set_cursor_mode(CURSOR_OFF);
				lcd_clear();
				lcd_write_str(motor_off);
				motor_set_speed(0); //turns off the motor
				if(key == '2' && pwr==0) //switch to other state?
				{
					next_state = MOTOR_ON;
				}
				break;
				
			case MOTOR_ON:
				lcd_set_cursor_mode(CURSOR_OFF);
				lcd_clear();
				lcd_write_str(motor_on);
				if(key == '1')//switch to other state?
				{
					next_state = MOTOR_OFF;
				}
				if(pwr > 0)//switch to other state?
				{
					next_state = MOTOR_RUNNING;
				}
				break;
				
			case MOTOR_RUNNING:
				sprintf(motor_str, "%u%c", regulator_read_power(), 0x25);
				output_msg(motor_running, motor_str, 0);
				motor_set_speed(pwr);
				if(key == '1')//switch to other state?
				{
					next_state = MOTOR_OFF;
				}
				break;
		}      
		current_state = next_state;
    }
}