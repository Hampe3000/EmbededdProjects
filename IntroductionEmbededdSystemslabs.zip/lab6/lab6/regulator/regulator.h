﻿/*
 * temp.h
 *
 * This is the device driver for the LM35 temperature sensor.
 *
 * Author:	Mathias Beckius, Hampus & Robin 
 * Created 04/01-2022
 */ 

#ifndef TEMP_H_
#define TEMP_H_

#include <inttypes.h>

enum state
{
	MOTOR_OFF,	// Visar motor av
	MOTOR_ON,	// visar motor
	MOTOR_RUNNING	// visar motor kör
};

typedef enum state state_t;

void regulator_init(void);
uint8_t regulator_read_power(void);

#endif /* TEMP_H_ */