N = 600;
%fs = 800;
[y_orig, fs] = audioread('ekg.mp3');
y_orig = y_orig(1:20000)
y = y_orig +rand(size(y_orig))*0.5-0.25;

% filter
y = filter(Num, 1 , y);

x = linspace(0,fs/N,N);
%y = sin(50*(2*pi*x))+0.5*sin(80*(2*pi*x))+randn(1,N);
%plot(fft(y));
R = fft(y);
R = R(1:N/2+1);
R = R/N;
R(2:end-1)= 2*R(2:end-1);
R = abs(R);
%x = linspace(0, fs/N, N/2+1);
%R(100:500) = 0;
%R(1:90) = 0;
%R(120:600) = 0;
plot(R)
% plot(x, R)
%plot(real(ifft(R)))

